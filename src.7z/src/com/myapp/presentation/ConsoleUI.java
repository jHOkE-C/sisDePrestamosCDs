package com.myapp.presentation; 

import java.util.Scanner; 

public class ConsoleUI { 
    public static void main(String[] args) { 
        Scanner sc = new Scanner(System.in); 
        LoanFacade facade = new LoanFacade(); 
        LoanRequestDTO dto = new LoanRequestDTO(); 

        try {
            System.out.print("Título: "); 
            dto.setTitle(sc.nextLine()); 

            System.out.print("Tipo (DVD/BluRay): "); 
            dto.setType(sc.nextLine()); 

            System.out.print("Días: "); 
            dto.setDays(sc.nextInt()); 

            System.out.print("Socio (s/n): "); 
            dto.setMember(sc.next().equalsIgnoreCase("s")); 

            System.out.print("Seguro (s/n): "); 
            dto.setInsurance(sc.next().equalsIgnoreCase("s")); 

            try { 
                double cost = facade.submitLoan(dto); 
                System.out.printf("Costo total: %.2f Bs%n", cost); 
            } catch (Exception ex) { 
                System.out.println("Error: " + ex.getMessage()); 
            }
        } finally {
            sc.close(); // Cerramos el Scanner para evitar la fuga de recursos
        }
    } 
}