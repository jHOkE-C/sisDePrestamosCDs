package com.myapp.business; 

public abstract class MediaFactory { 
    public abstract MediaItem createMedia(String title); 
}