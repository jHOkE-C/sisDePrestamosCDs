package com.myapp.business; 

public class BluRay extends MediaItem { 
    public BluRay(String title) { super(title); } 
    public double getPricePerDay() { return 2.0; } 
}